/* ==========================================================================
   Yoga & Thai-Yoga Anja Tandel – Interaktionen (ohne Abhängigkeiten)
   Inhalte (Kontakt, Events) stehen in assets/js/site-data.js
   ========================================================================== */
(() => {
  'use strict';

  const SITE = window.SITE || {};
  const contact = SITE.contact || {};
  const events = Array.isArray(SITE.events) ? SITE.events : [];

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /** Jeder Baustein läuft für sich: ein Fehler legt nicht die ganze Seite lahm. */
  const safe = (fn) => {
    try { fn(); } catch (err) { console.error(`[Seite] ${fn.name} fehlgeschlagen:`, err); }
  };

  /* ---------- kleine DOM-Helfer ---------- */
  const SVG_NS = 'http://www.w3.org/2000/svg';

  function h(tag, props = {}, ...kids) {
    const el = document.createElement(tag);
    for (const [key, value] of Object.entries(props)) {
      if (value === undefined || value === null || value === false) continue;
      if (key === 'class') el.className = value;
      else el.setAttribute(key, value === true ? '' : value);
    }
    kids.flat().forEach((kid) => {
      if (kid === undefined || kid === null || kid === false) return;
      el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    });
    return el;
  }

  function icon(id) {
    const svg = document.createElementNS(SVG_NS, 'svg');
    svg.setAttribute('class', 'icon');
    svg.setAttribute('aria-hidden', 'true');
    const use = document.createElementNS(SVG_NS, 'use');
    use.setAttribute('href', `#${id}`);
    svg.append(use);
    return svg;
  }

  /* ---------- Kontakt: WhatsApp, Telefon, E-Mail, Adresse ---------- */
  /** Wandelt Eingaben wie „0170 1234567“ oder „+49 170 …“ in das wa.me-Format (nur Ziffern, mit Landesvorwahl). */
  function toInternational(raw) {
    const s = String(raw || '').trim();
    let digits = s.replace(/\D/g, '');
    if (!digits) return '';
    if (s.startsWith('+')) { /* Landesvorwahl steht bereits da */ }
    else if (digits.startsWith('00')) digits = digits.slice(2);
    else if (digits.startsWith('0')) digits = `49${digits.slice(1)}`; // Standard: Deutschland
    // „+49 0173 …“: Die Null nach der Landesvorwahl gehört nicht zur Nummer und bricht wa.me- und tel:-Links.
    if (digits.startsWith('490')) digits = `49${digits.slice(3)}`;
    return digits;
  }

  const waNumber = toInternational(contact.whatsapp || contact.phone);

  function applyWhatsApp(el, text) {
    if (!waNumber) { el.setAttribute('href', '#kontakt'); return el; }
    const query = text ? `?text=${encodeURIComponent(text)}` : '';
    el.setAttribute('href', `https://wa.me/${waNumber}${query}`);
    el.setAttribute('target', '_blank');
    el.setAttribute('rel', 'noopener noreferrer');
    return el;
  }

  function fillLines(el, lines) {
    el.replaceChildren();
    lines.forEach((line, i) => {
      if (i) el.append(document.createElement('br'));
      el.append(document.createTextNode(line));
    });
  }

  function initContacts() {
    $$('[data-wa]').forEach((a) => applyWhatsApp(a, a.dataset.waText));

    const phone = contact.phone || contact.whatsapp;
    if (phone) {
      const intl = toInternational(phone);
      $$('[data-contact="phone"]').forEach((a) => {
        a.textContent = phone;
        a.setAttribute('href', `tel:+${intl}`);
      });
    }

    if (contact.email) {
      $$('[data-contact="email"]').forEach((a) => {
        a.textContent = contact.email;
        a.setAttribute('href', `mailto:${contact.email}`);
      });
      $$('[data-contact="email-button"]').forEach((a) => a.setAttribute('href', `mailto:${contact.email}`));
    } else {
      // Ohne Adresse wäre der Button ein Blindgänger – bis zur Eingabe ausblenden.
      $$('[data-contact="email-button"]').forEach((a) => { a.hidden = true; });
    }

    if (Array.isArray(contact.address) && contact.address.length) {
      $$('[data-contact="address"], [data-contact="address-dark"]').forEach((el) => fillLines(el, contact.address));
    }

    if (contact.mapsUrl) {
      $$('[data-contact="maps"]').forEach((a) => {
        a.setAttribute('href', contact.mapsUrl);
        a.setAttribute('target', '_blank');
        a.setAttribute('rel', 'noopener noreferrer');
        a.hidden = false;
      });
    }

    if (contact.hours) {
      $$('[data-contact="hours"]').forEach((el) => { el.textContent = contact.hours; });
    }

    $$('[data-year]').forEach((el) => { el.textContent = String(new Date().getFullYear()); });
  }

  /* ---------- Einblenden beim Scrollen ---------- */
  function initReveal() {
    const items = $$('.reveal');
    if (!items.length) return;
    if (reduceMotion || !('IntersectionObserver' in window)) {
      items.forEach((el) => el.classList.add('is-visible'));
      return;
    }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        io.unobserve(entry.target);
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.12 });
    items.forEach((el) => io.observe(el));
  }

  /* ---------- Kopfbereich: Schatten, mobiles Menü, aktiver Abschnitt ---------- */
  function initHeader() {
    const header = $('[data-header]');
    const nav = $('[data-nav]');
    const toggle = $('[data-menu-toggle]');
    if (!header) return;

    const onScroll = () => header.classList.toggle('is-scrolled', window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });

    if (!nav || !toggle) return;
    const setOpen = (open) => {
      nav.classList.toggle('is-open', open);
      toggle.setAttribute('aria-expanded', String(open));
      toggle.setAttribute('aria-label', open ? 'Menü schließen' : 'Menü öffnen');
    };
    toggle.addEventListener('click', () => setOpen(!nav.classList.contains('is-open')));
    nav.addEventListener('click', (e) => { if (e.target.closest('a')) setOpen(false); });
    document.addEventListener('click', (e) => {
      if (nav.classList.contains('is-open') && !header.contains(e.target)) setOpen(false);
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && nav.classList.contains('is-open')) { setOpen(false); toggle.focus(); }
    });
    window.matchMedia('(min-width: 960px)').addEventListener('change', (e) => { if (e.matches) setOpen(false); });
  }

  function initScrollSpy() {
    if (!('IntersectionObserver' in window)) return;
    const links = $$('.nav__list a[href^="#"]');
    const byId = new Map();
    links.forEach((a) => {
      const id = a.getAttribute('href').slice(1);
      const section = id && document.getElementById(id);
      if (section) byId.set(section, a);
    });
    if (!byId.size) return;
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        const link = byId.get(entry.target);
        if (!link) return;
        if (entry.isIntersecting) {
          links.forEach((l) => l.classList.remove('is-active'));
          link.classList.add('is-active');
        } else {
          link.classList.remove('is-active');
        }
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    byId.forEach((_, section) => io.observe(section));
  }

  /* ---------- Angebote: Accordion + Bildwechsel ---------- */
  function initOffers() {
    const items = $$('.acc');
    if (!items.length) return;
    const imgs = $$('.offers__img');
    const note = $('[data-offers-note]');

    const show = (id) => {
      imgs.forEach((img) => img.classList.toggle('is-active', img.dataset.offer === id));
      const item = items.find((i) => i.dataset.offer === id);
      if (note && item && item.dataset.note) note.textContent = item.dataset.note;
    };

    items.forEach((item) => {
      item.addEventListener('toggle', () => {
        if (!item.open) return;
        items.forEach((other) => { if (other !== item) other.open = false; }); // auch ohne native Gruppenfunktion
        show(item.dataset.offer);
      });
    });

    // Startzustand aus dem geöffneten Eintrag ableiten, damit Hinweis und Bild nie vom Text abweichen.
    const initial = items.find((item) => item.open);
    if (initial) show(initial.dataset.offer);
  }

  /* ---------- Events: Sortierung nach Datum + Tabs ---------- */
  const today = (() => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; })();

  function parseISO(value) {
    if (!value) return null;
    const [y, m, d] = String(value).split('-').map(Number);
    return y && m && d ? new Date(y, m - 1, d) : null;
  }

  /** Ohne Datum gilt ein Event als kommend; mehrtägige gelten bis zum letzten Tag. */
  const isUpcoming = (ev) => {
    const end = parseISO(ev.endDate) || parseISO(ev.date);
    return !end || end >= today;
  };

  const dateKey = (ev) => (parseISO(ev.date) || new Date(8640000000000000)).getTime();

  function dateText(ev) {
    if (ev.dateLabel) return ev.dateLabel;
    const d = parseISO(ev.date);
    return d ? new Intl.DateTimeFormat('de-DE', { day: 'numeric', month: 'long', year: 'numeric' }).format(d) : 'Datum folgt';
  }

  function eventImg(image, className, sizes) {
    return h('img', {
      class: className, src: image.src, srcset: image.srcset, sizes,
      width: image.w, height: image.h, alt: image.alt || '', loading: 'lazy', decoding: 'async',
      style: image.position ? `object-position: ${image.position}` : null
    });
  }

  function whatsappButton(label, text, cls = 'btn btn--primary') {
    const a = h('a', { class: cls }, icon('i-chat'), label);
    return applyWhatsApp(a, text);
  }

  function metaLine(ev, badge) {
    const when = ev.date
      ? h('time', { datetime: ev.date }, dateText(ev))
      : h('span', {}, dateText(ev));
    return h('p', { class: 'event-meta' }, badge, when, ev.place ? h('span', {}, ev.place) : null);
  }

  const upcomingBadge = (ev) => (ev.placeholder
    ? h('span', { class: 'badge badge--placeholder' }, 'Platzhalter')
    : h('span', { class: 'badge badge--soon' }, 'Kommend'));

  /** Eigener Anmelde-Link, sonst eine WhatsApp-Nachricht mit Event-Titel und Datum. */
  function upcomingCta(ev) {
    if (ev.link) {
      return h('a', { class: 'btn btn--primary', href: ev.link, target: '_blank', rel: 'noopener noreferrer' }, 'Zur Anmeldung', icon('i-arrow'));
    }
    // Ohne festen Termin ist „Anmelden“ noch nicht möglich: stattdessen Interesse bekunden.
    const open = ev.placeholder || !ev.date;
    return whatsappButton(
      open ? 'Interesse? Schreib mir' : 'Anmelden oder nachfragen',
      open
        ? `Hallo Anja, ich interessiere mich für „${ev.title}“. Sagst du mir Bescheid, sobald der Termin feststeht?`
        : `Hallo Anja, ich interessiere mich für „${ev.title}“ (${dateText(ev)}). Gibt es noch Plätze?`
    );
  }

  function upcomingCard(ev) {
    const hasImage = ev.images && ev.images[0];
    const media = h('div', { class: 'event-card__media' },
      hasImage
        ? eventImg(ev.images[0], 'event-card__img', '(min-width: 900px) 30vw, 90vw')
        : h('img', { class: 'event-card__mark', src: 'assets/img/ginkgo-icon.png', width: 240, height: 190, alt: '' }));

    return h('article', { class: `event-card${ev.placeholder ? ' event-card--placeholder' : ''}` },
      media,
      h('div', { class: 'event-card__body' },
        metaLine(ev, upcomingBadge(ev)),
        h('h3', {}, ev.title),
        ev.summary ? h('p', {}, ev.summary) : null,
        ev.tags && ev.tags.length ? h('ul', { class: 'chips' }, ev.tags.map((t) => h('li', {}, t))) : null,
        h('div', { class: 'event-card__cta' }, upcomingCta(ev))));
  }

  /** Große Darstellung: für das jüngste Rückblick-Event und für ein einzelnes kommendes Event. */
  function featureEvent(ev, kind) {
    const isPast = kind === 'past';
    const gallery = (ev.images || []).slice(0, 3);
    const sizes = '(min-width: 900px) 24vw, 45vw';
    const media = gallery.length
      ? h('div', { class: 'feature__gallery', 'data-count': String(gallery.length) },
        gallery.map((img) => h('figure', {}, eventImg(img, '', sizes))))
      : h('div', { class: 'feature__media' },
        h('img', { class: 'feature__mark', src: 'assets/img/ginkgo-icon.png', width: 240, height: 190, alt: '' }));

    return h('article', { class: `feature${ev.placeholder ? ' feature--placeholder' : ''}` },
      media,
      h('div', { class: 'feature__body' },
        metaLine(ev, isPast ? h('span', { class: 'badge badge--past' }, 'Rückblick') : upcomingBadge(ev)),
        h('h3', {}, ev.title),
        ev.host ? h('p', { class: 'feature__host' }, ev.host) : null,
        ev.summary ? h('p', {}, ev.summary) : null,
        ev.tags && ev.tags.length ? h('ul', { class: 'chips' }, ev.tags.map((t) => h('li', {}, t))) : null,
        isPast && ev.pullquote
          ? h('blockquote', { class: 'feature__quote' }, `„${ev.pullquote}“`, ev.pullquoteBy ? h('small', {}, ev.pullquoteBy) : null)
          : null,
        isPast
          ? h('a', { class: 'link-arrow', href: '#stimmen' }, 'Rezensionen lesen', icon('i-arrow'))
          : upcomingCta(ev)));
  }

  function pastCard(ev) {
    const media = ev.images && ev.images[0]
      ? h('div', { class: 'event-card__media' }, eventImg(ev.images[0], 'event-card__img', '(min-width: 900px) 30vw, 90vw'))
      : null;
    return h('article', { class: 'event-card' },
      media,
      h('div', { class: 'event-card__body' },
        metaLine(ev, h('span', { class: 'badge badge--past' }, 'Rückblick')),
        h('h3', {}, ev.title),
        ev.summary ? h('p', {}, ev.summary) : null));
  }

  function emptyUpcoming() {
    return h('div', { class: 'empty' },
      h('img', { class: 'empty__mark', src: 'assets/img/ginkgo-icon.png', width: 240, height: 190, alt: '' }),
      h('h3', {}, 'Neue Termine folgen'),
      h('p', {}, 'Aktuell ist noch nichts terminiert. Schreib mir, dann sage ich dir Bescheid, sobald es losgeht.'),
      whatsappButton('Bescheid sagen lassen', 'Hallo Anja, bitte sag mir Bescheid, sobald es neue Events gibt.'));
  }

  function initEvents() {
    const root = $('[data-tabs]');
    if (!root) return;

    const upcoming = events.filter(isUpcoming).sort((a, b) => dateKey(a) - dateKey(b));
    const past = events.filter((ev) => !isUpcoming(ev)).sort((a, b) => dateKey(b) - dateKey(a));

    const upcomingPanel = $('[data-panel="upcoming"]', root);
    const pastPanel = $('[data-panel="past"]', root);

    // 0 Events: freundlicher Leerzustand · 1 Event: große Darstellung · mehrere: Karten-Raster
    upcomingPanel.replaceChildren(
      upcoming.length === 0 ? emptyUpcoming()
        : upcoming.length === 1 ? featureEvent(upcoming[0], 'upcoming')
          : h('div', { class: 'event-grid' }, upcoming.map(upcomingCard))
    );

    if (past.length) {
      const [latest, ...older] = past;
      pastPanel.replaceChildren(
        featureEvent(latest, 'past'),
        older.length ? h('div', { class: 'event-grid feature-more' }, older.map(pastCard)) : null
      );
    } else {
      pastPanel.replaceChildren(h('p', { class: 'notice' }, 'Hier erscheinen vergangene Events, sobald es welche gibt.'));
    }

    const upCount = $('[data-count="upcoming"]', root);
    const pastCount = $('[data-count="past"]', root);
    if (upCount) upCount.textContent = String(upcoming.length);
    if (pastCount) pastCount.textContent = String(past.length);

    /* Tabs nach ARIA-Muster: Pfeiltasten, Pos1/Ende, nur der aktive Tab ist per Tab-Taste erreichbar */
    const tabs = $$('[role="tab"]', root);
    const panelOf = (tab) => document.getElementById(tab.getAttribute('aria-controls'));

    const select = (tab, { focus = false } = {}) => {
      tabs.forEach((t) => {
        const on = t === tab;
        t.setAttribute('aria-selected', String(on));
        t.tabIndex = on ? 0 : -1;
        const panel = panelOf(t);
        panel.hidden = !on;
        if (on && !reduceMotion) { panel.classList.remove('is-entering'); void panel.offsetWidth; panel.classList.add('is-entering'); }
      });
      if (focus) tab.focus();
    };

    tabs.forEach((tab, i) => {
      tab.addEventListener('click', () => select(tab));
      tab.addEventListener('keydown', (e) => {
        const last = tabs.length - 1;
        const next = { ArrowRight: (i + 1) % tabs.length, ArrowLeft: (i - 1 + tabs.length) % tabs.length, Home: 0, End: last }[e.key];
        if (next === undefined) return;
        e.preventDefault();
        select(tabs[next], { focus: true });
      });
    });

    // Gibt es nichts Kommendes, aber Vergangenes, startet die Übersicht im Rückblick.
    // Ist gar nichts da, bleibt „Kommend“ vorn, denn dort steht die Aufforderung zum Nachfragen.
    select(upcoming.length || !past.length ? tabs[0] : tabs[1]);
  }

  /* ---------- Schwebender WhatsApp-Button (mobil) ---------- */
  function initFab() {
    const fab = $('[data-fab]');
    const hero = $('.hero');
    const contactSection = $('#kontakt');
    if (!fab || !hero || !('IntersectionObserver' in window)) return;
    let pastHero = false;
    let inContact = false;
    const update = () => fab.classList.toggle('is-visible', pastHero && !inContact);
    new IntersectionObserver(([entry]) => { pastHero = !entry.isIntersecting; update(); }, { threshold: 0.05 }).observe(hero);
    if (contactSection) {
      new IntersectionObserver(([entry]) => { inContact = entry.isIntersecting; update(); }, { threshold: 0.2 }).observe(contactSection);
    }
  }

  /* ---------- Start ---------- */
  [initReveal, initContacts, initHeader, initScrollSpy, initOffers, initEvents, initFab].forEach(safe);
})();
