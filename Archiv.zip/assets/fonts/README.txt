Schriften (lokal eingebunden, keine Verbindung zu Google)

- Lora (variable, Latin)    - SIL Open Font License 1.1 - (c) The Lora Project Authors
- Raleway (variable, Latin) - SIL Open Font License 1.1 - (c) The Raleway Project Authors

Quelle: Fontsource (npm: @fontsource-variable/lora@5.3.0, @fontsource-variable/raleway@5.3.0),
ausgeliefert ueber jsDelivr. Dateien unveraendert uebernommen.
