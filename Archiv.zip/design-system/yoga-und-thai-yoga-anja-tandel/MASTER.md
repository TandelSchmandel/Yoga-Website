# Design-System: Yoga & Thai-Yoga Anja Tandel (Master)

> Gilt für die One-Pager-Landingpage `index.html`. Gibt es unter `pages/` eine Datei für eine
> bestimmte Seite, überschreibt sie diese Regeln. Die Werte hier entsprechen dem gebauten Stand
> (`assets/css/styles.css`); bei Widersprüchen gewinnt der Code, und diese Datei wird nachgezogen.

**Stand:** 2026-10-16 · **Stil:** Organic Biophilic (ui-ux-pro-max), an Anjas Branding angepasst
**Dials:** Variance 5 (ausgewogen, mit Rundbogen als Eigenheit) · Motion 4 (dezent) · Density 3 (luftig)

---

## 1. Marke

| | |
|---|---|
| Name | Yoga & Thai-Yoga **Anja Tandel** |
| Logo | **Hauptlogo:** Ginkgo-Yin-Yang-Kreis aus `images/logo Kopie.png` (`assets/img/logo-156.png` in Kopf- und Fußbereich sowie als Favicon; `ginkgo-logo.png` als große, dezente Fläche). Das Zwei-Blätter-Icon (`ginkgo-icon.png`) dient nur noch als kleines Deko-Icon. |
| Kernbotschaft | **„Ankommen & Fühlen, Träumen & Loslassen“** (vorgegeben, steht als H1) |
| Angebote | Yoga-Kurse (Somatic Yoga) · Qigong · Thai-Yoga-Massage · **Sensitives Coaching** · Retreats & Workshops |
| Haupt-Aktion | WhatsApp-Nachricht mit Vorlagentext je Angebot; zusätzlich Telefon und E-Mail im Kontaktbereich |
| Ton | Du-Ansprache, ruhig und warm; Anja spricht in der Ich-Form |
| Vorbild | Referenzbild „Yoganova Studio“: runde Hero-Karte, großes Typo-Band, Accordion, Tabs. Farben, Logo, Bilder, Sektionen und Texte sind eigen. |

## 2. Farben

Direkt aus dem Logo gemessen (Hauptfarben: `#5B724C`, `#899A62`, `#34472B`, Icon `#64783D`), dazu Creme als Fläche
und ein Kork-Ton aus den Studiofotos. Alle Textkombinationen sind rechnerisch gegen WCAG AA geprüft.

| Token | Hex | Einsatz | Kontrast |
|---|---|---|---|
| `--green-800` | `#34472B` | Buttons, dunkle Bänder, aktiver Tab | creme-50 darauf: 9,6 : 1 |
| `--green-700` | `#44593A` | Eyebrow-Labels, Hover | auf Creme: 6,8 : 1 |
| `--green-600` | `#5B724C` | zweite Statement-Hälfte, Icons | auf Creme: 4,7 : 1 |
| `--green-300` | `#899A62` | nur dekorativ (Linien, Rahmen) | nie für Text |
| `--green-200` | `#C9D3B0` | Text auf dunklem Grün | auf green-800: 6,5 : 1 |
| `--green-100` | `#E4E9D6` | Chips, Flächen | green-800 darauf: 8,1 : 1 |
| `--cream-100` | `#F5F1E4` | Seitenhintergrund | ink darauf: 12,9 : 1 |
| `--cream-50` | `#FBF9F2` | Karten | |
| `--cream-200` | `#EAE4D0` | Tab-Leiste, Badges | |
| `--cork-500` | `#B9824A` | nur dekorativ (zu wenig Kontrast für Text) | |
| `--cork-700` | `#7A4E25` | Platzhalter-Markierungen (`.todo`) | 5,4 : 1 |
| `--ink` / `--ink-soft` | `#232B1E` / `#4F5A44` | Text / gedämpfter Text | 12,9 : 1 / 6,5 : 1 |

Kein Dark Mode vorgesehen (warme Creme-Welt ist Teil der Marke).

## 3. Typografie

- **Überschriften:** Lora (variabel 400–700), Gewicht 500; Kursivschnitt für Labels, Namen und Zitate.
- **Text:** Raleway (variabel), 17 px mobil / 18 px ab 900 px, Zeilenhöhe 1,65; `font-variant-numeric: lining-nums`.
- **Lokal gehostet** (`assets/fonts/`, Fontsource 5.3.0, OFL): keine Verbindung zu Google, datenschutzfreundlich, schnell.
- **Fluide Größen:** H1 `clamp(2.5rem, 1.1rem + 6.2vw, 5rem)`, H2 `clamp(2rem, 1.2rem + 2.6vw, 3.5rem)`.
- Silbentrennung aus (`hyphens: manual`), `text-wrap: balance` für Überschriften, `pretty` für Absätze.

## 4. Form, Raum, Layout

- **Rundbogen** als Markenform (spiegelt die Bögen im Studio): Porträt im „ANJA“-Band, Tür-Foto in der Galerie.
- Radien: Karten 24 px, große Flächen 36 px, Buttons voll rund.
- Container 1240 px, Gutter `clamp(16px, 4vw, 40px)`; Abschnittsabstand `clamp(60px, 7.5vw, 104px)`.
- Kopfbereich: schwebende, leicht unscharfe Pille (sticky). Mobil: Menü-Panel; zusätzlich schwebender WhatsApp-Button.
- Breakpoints: 900 (Zwei-Spalten-Layouts), 960 (Desktop-Navigation), 1100 (Hero-Karte und Seitenschriftzug).

## 5. Bausteine

- **Buttons:** Pille, mind. 48 px hoch; primär `green-800`; hell `cream-100` und Ghost-hell (auf Dunkelgrün); Ghost (helles Glas, dunkle Schrift) im Hero.
- **Hero (clean, Entscheidung 2026-10-22):** helles Wasser-Bild (`images/background1.webp`), Überschrift und zwei Buttons zentriert in dunkler Schrift (kleinster Kontrast auf den Bildpixeln 6,7 : 1). Bewusst **ohne** Pills, Fließtext und Willkommenszeile. Ab 1100 px zusätzlich die Karte „Hallo, ich bin Anja“ (helles Glas) und ein vertikaler Schriftzug.
- **Accordion (Angebote):** natives `<details name>`; Bild links wechselt per Überblendung, mobil Bild im Panel.
- **Tabs (Events):** ARIA-Tabmuster mit Pfeiltasten, Pos1/Ende und rollendem `tabindex`.
- **Event-Darstellung:** 0 kommende → Leerzustand mit Kontakt-Aufforderung · 1 → große Feature-Ansicht · 2+ → Karten-Raster.
  Zuordnung zu „Kommend“/„Rückblick“ automatisch nach Datum (`assets/js/site-data.js`).
- **Platzhalter:** gestrichelte Karten mit „Platzhalter“-Badge und `.todo`-Markierungen im Text; alles Sichtbare, das noch fehlt.

## 6. Bewegung

Einblenden beim Scrollen (Opacity + 18 px, 800 ms), Hero-Bild setzt sich ein (2 s), Logo-Scheibe „atmet“ (9 s, ±4,5 %),
Accordion-Panel gleitet ein. Alles unter `prefers-reduced-motion: reduce` abgeschaltet. Keine Bibliotheken.

## 7. Sektionen (Reihenfolge)

Kopfbereich → Hero → Statement → Angebote → Dein Weg (Ankommen · Fühlen · Träumen · Loslassen) → Über mich →
Studio → Events → Rezensionen (zwei Karten, die lange einklappbar) → Kontakt → Fußbereich (Impressum, Datenschutz).

## 8. Inhaltsregeln

- **Menü (Wortlaut vom Auftraggeber):** Angebote · Über Mich · Studio · Events · Rezensionen · Kontakt. „Über Mich“ gilt überall, wo auf den Abschnitt verwiesen wird.

- **Texte vom Auftraggeber:** Die Beschreibungen von Yoga-Kurse, Thai-Yoga-Massage, Qigong und Sensitives Coaching sowie der Über-mich-Text (inkl. Wasser-Zitat) stammen von Anja selbst und werden nur in Rechtschreibung und Zeichensetzung korrigiert, nicht umformuliert. Noch KI-Entwurf: Retreats & Workshops, Statement/Intro, „Dein Weg“, Studio.
- **Nichts erfinden:** keine Ausbildungen, Jahre, Zahlen, Preise oder Zertifikate. Fehlendes bleibt als `.todo`-Platzhalter stehen.
- Fotos mit erkennbaren Teilnehmenden und das Zitat von Teresa nur mit deren Einwilligung veröffentlichen.
  Das Original `images/IMG-20260912-WA0033.webp` (Teilnehmerin erkennbar) ist bewusst **nicht** eingebaut und hat keine Web-Kopie in `assets/img/`.
- Rechtstexte (Impressum, Datenschutz) schreibt nicht die KI: Sie stammen aus dem eRecht24-Generator (Hoster Hostinger, lokale Schriften) und wurden nur in Layout und Telefonformat angepasst. Die Quellenangabe von eRecht24 bleibt stehen.
- Rezensionen werden unverändert übernommen (nur Emojis entfernt, da Icons ausschließlich SVG sind); anonyme Rückmeldungen werden als „Anonym“ ausgewiesen.

## 9. Abweichungen von der Datenbank-Empfehlung

| Datenbank | Umgesetzt | Grund |
|---|---|---|
| Palette Blaugrau + Teal-Akzent `#0891B2` | Logo-Palette Grün + Creme + Kork | Branding des Auftraggebers; Teal lebt nur in den Fotos (Decken) |
| Schriften über Google-Fonts-CDN | lokal eingebunden | DSGVO (IP-Weitergabe an Google), Geschwindigkeit |
| Muster „Hero + Testimonials + CTA“ mit Karussell | erweitert um Angebote, Studio, Events; einzelne Stimme statt Karussell | Es gibt aktuell nur eine Stimme; ein Karussell wäre Ballast |
| Akzentfarbe für Haupt-Button | dunkles Logo-Grün | beste Lesbarkeit, bleibt in der Markenwelt |

## 10. Prüfstand vor Auslieferung (erledigt am 2026-10-16)

- [x] Keine Emojis als Icons (SVG, Lucide-Stil) · [x] Hover-Übergänge 250–350 ms · [x] `cursor: pointer` auf Bedienelementen
- [x] Fokus überall sichtbar, Skip-Link · [x] Kontraste (20 Paare) ≥ AA · [x] `prefers-reduced-motion` respektiert
- [x] Kein horizontaler Überlauf bei 320, 375, 768, 1024, 1440, 1920 px · [x] Bilder mit Breite/Höhe, Lazy Loading unterhalb des Hero
- [x] Genau eine H1, alle Bilder mit `alt`, keine toten Anker, keine doppelten IDs · [x] Menü, Accordion, Tabs per Tastatur bedienbar
