/* ==========================================================================
   Pflegbare Inhalte – hier ändern sich Kontaktdaten und Events,
   ohne dass an Layout oder Code etwas angefasst werden muss.

   KONTAKT
   - whatsapp: Mobilnummer, z. B. "0170 1234567" oder "+49 170 1234567".
     Alle WhatsApp-Buttons der Seite verlinken danach automatisch dorthin
     (mit einem passenden Vorlagentext je Angebot).
   - Solange ein Feld leer ist, zeigt die Seite einen sichtbaren Platzhalter.

   EVENTS
   - Jedes Event ist ein Block { … } in der Liste "events".
   - "date" (JJJJ-MM-TT) entscheidet automatisch, ob ein Event unter
     "Kommend" oder "Rückblick" erscheint. Mehrtägig? Dann zusätzlich
     "endDate" setzen: bis dahin gilt das Event noch als kommend.
   - Ohne "date" gilt ein Event als kommend (z. B. "Datum folgt").
   - "dateLabel" ist der Text, der auf der Seite steht (z. B. "14.–16. Nov 2026").
   - "placeholder: true" markiert einen Eintrag sichtbar als Platzhalter (gestrichelt).
   - Bilder: Dateien nach assets/img/ legen und unter "images" eintragen.
   - Eigener Anmelde-Link? Dann "link" setzen (sonst WhatsApp-Nachricht).
   ========================================================================== */

window.SITE = {
  contact: {
    whatsapp: "+49 173 6057610",   // z. B. "0170 1234567" oder "+49 170 1234567"
    phone: "+49 173 6057610",      // optional, falls abweichend von der WhatsApp-Nummer
    email: "at-yoga@web.de",
    address: ["Sorbenaue 22", "06686 Zorbau"],   // Studio (die Impressumsadresse steht in impressum.html)
    mapsUrl: "https://www.google.com/maps/dir/?api=1&destination=Sorbenaue%2022%2C%2006686%20Zorbau",
    hours: "Kurse nach Absprache"
  },

  events: [
    /* ---------- Rückblick: das Retreat im September 2026 ---------- */
    {
      id: "yoga-retreat-2026-09",
      title: "Yoga-Retreat: drei Tage Auszeit",
      date: "2026-09-11",
      endDate: "2026-09-13",
      dateLabel: "11.–13. September 2026",
      place: "Im Studio",
      host: "mit Anja und Franzi",
      summary:
        "Drei Tage zum Runterfahren: Yoga, Lern- und Entspannungsübungen, " +
        "neue Massage-Techniken und Zeit für bereichernde Gespräche – in ruhiger Atmosphäre, " +
        "mit Kerzenlicht, warmen Decken und viel Raum zum Loslassen.",
      tags: ["3 Tage", "Yoga", "Massage-Techniken", "Entspannung"],
      pullquote: "Ich empfehle es von Herzen weiter!",
      pullquoteBy: "Teresa, Teilnehmerin",
      images: [
        {
          src: "assets/img/retreat-karten-1000.jpg",
          srcset: "assets/img/retreat-karten-560.jpg 560w, assets/img/retreat-karten-1000.jpg 1000w",
          w: 1000, h: 1331,
          alt: "Ein Kreis aus Karten mit Rosen, Kerzen und Klangschalen auf dem Korkboden"
        },
        {
          src: "assets/img/retreat-ruhe-1000.jpg",
          srcset: "assets/img/retreat-ruhe-560.jpg 560w, assets/img/retreat-ruhe-1000.jpg 1000w",
          w: 1000, h: 1331,
          alt: "Tiefenentspannung unter einer türkisen Decke, daneben kniet eine Kursleiterin mit den Händen vor der Brust"
        },
        {
          src: "assets/img/retreat-gruppe-1000.jpg",
          srcset: "assets/img/retreat-gruppe-560.jpg 560w, assets/img/retreat-gruppe-1000.jpg 1000w",
          w: 1000, h: 1333,
          alt: "Teilnehmende sitzen im Gespräch auf türkisen Decken im Studio unter Holzbalken"
        }
      ]
    },

    /* ---------- Vorlagen für kommende Events ----------
       Ohne "date" gelten Events als kommend und zeigen den "dateLabel".
       Sobald ein Termin feststeht: "date" (JJJJ-MM-TT), "dateLabel", Titel, Text und Preis anpassen.
       Fürs Löschen einfach den ganzen Block { … } entfernen. */
    {
      id: "vorlage-workshop",
      title: "Workshop",
      dateLabel: "Termin folgt",
      place: "Im Studio",
      summary:
        "Ein Workshop zum Eintauchen und Ausprobieren. Thema, Termin und Preis gebe ich hier bekannt, " +
        "sobald sie feststehen. Schreib mir gern, dann sage ich dir Bescheid.",
      tags: ["Workshop", "Termin folgt"],
      images: [
        {
          src: "assets/img/workshop-vorlage-1000.jpg",
          srcset: "assets/img/workshop-vorlage-560.jpg 560w, assets/img/workshop-vorlage-1000.jpg 1000w",
          w: 1000, h: 1500, position: "50% 40%",
          alt: "Zwei Teilnehmerinnen sitzen auf Matten und blicken in einen grünen Garten"
        }
      ]
    },
    {
      id: "vorlage-retreat",
      title: "Nächstes Retreat",
      dateLabel: "Termin folgt",
      summary:
        "Mehrere Tage zum Runterfahren, mit Yoga, Entspannung und Zeit für Gespräche. " +
        "Datum, Ort und Preis gebe ich hier bekannt, sobald sie feststehen. Schreib mir gern, dann sage ich dir Bescheid.",
      tags: ["Retreat", "Termin folgt"],
      images: [
        {
          src: "assets/img/retreat-vorlage-1000.jpg",
          srcset: "assets/img/retreat-vorlage-560.jpg 560w, assets/img/retreat-vorlage-1000.jpg 1000w",
          w: 1000, h: 1500, position: "50% 45%",
          alt: "Eine Yoga-Gruppe übt auf Matten in einer offenen, hölzernen Halle mit Blick ins Grüne"
        }
      ]
    }
  ]
};
