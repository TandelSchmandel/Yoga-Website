# Yoga & Thai-Yoga Anja Tandel: Landingpage

Statische One-Pager-Seite ohne Build-Schritt: reines HTML, CSS und JavaScript. Läuft bei jedem Hoster
(Netlify, GitHub Pages, ein normales Webhosting) und lässt sich direkt per Doppelklick auf `index.html` ansehen.

```
index.html              Die Seite (alle Sektionen, Texte)
impressum.html          Entwurf, muss ausgefüllt und rechtlich geprüft werden
datenschutz.html        Entwurf, muss ausgefüllt und rechtlich geprüft werden
assets/css/styles.css   Gestaltung (Farben und Maße stehen oben unter „Tokens“)
assets/js/site-data.js  ★ Kontaktdaten und Events: hier wird gepflegt
assets/js/main.js       Interaktionen (nicht anfassen müssen)
assets/img/             Web-Bilder (aus den Originalen in images/ erzeugt)
assets/fonts/           Schriften Lora und Raleway, lokal (kein Google)
design-system/          Design-Regeln für weitere Änderungen
images/                 Originalfotos, bleiben unverändert
```

## Was als Nächstes gepflegt werden muss

Fehlende Angaben stehen auf der Seite als **[Platzhalter in eckigen Klammern]** mit bräunlichem Hintergrund.
Kontaktdaten, Ausbildungen und Rechtstexte sind eingetragen. Offen sind nur noch die Events:

1. **Events** in `assets/js/site-data.js` pflegen. Ob ein Event unter „Kommend“ oder „Rückblick“ erscheint,
   entscheidet das Datum automatisch. Die zwei Vorlagen „Workshop“ und „Nächstes Retreat“ zeigen „Termin folgt“ und sind für die Veröffentlichung gedacht; Termin eintragen oder Block löschen.
2. **Kontaktdaten** ändern sich ebenfalls dort (`contact`). WhatsApp-Buttons, Telefon- und Mail-Links folgen automatisch.
   Nummern dürfen in jeder üblichen Schreibweise stehen, auch mit „+49 0173 …“ (die überzählige Null wird entfernt).
3. **Neue Rezension** in `index.html` im Abschnitt „Rezensionen“ als weitere `<figure class="quote">` ergänzen.
4. **Impressum und Datenschutz** stammen aus dem eRecht24-Generator (`impressum.html`, `datenschutz.html`).
   Ändert sich etwas (neuer Hoster, Kontaktformular, Analyse-Tool), muss der Text neu generiert werden.

## Vor dem Livegang

- [ ] Einwilligung von **Teresa** für das Zitat und von allen erkennbar abgebildeten Personen für die Fotos einholen (die anonyme Rezension wurde von Anja bereitgestellt)
- [ ] Impressum prüfen: Dort steht die Anschrift Bahnhofstraße 16, 06679 Hohenmölsen, das Studio liegt in Zorbau
- [ ] Die zwei Vorlagen „Workshop“ und „Nächstes Retreat“ (in `site-data.js`) mit echten Terminen füllen, sobald sie feststehen
- [ ] Foto für **Qigong** ergänzen (aktuell steht dort ein Porträt als Ersatz)
- [ ] Weihnachtsdeko auf einzelnen Studiofotos prüfen und ggf. durch neue Aufnahmen ersetzen

## Neues Foto einbauen

Foto nach `images/` legen, dann mit `sips` (auf jedem Mac vorhanden) verkleinern:

```bash
sips -s format jpeg -s formatOptions 78 --resampleWidth 1400 "images/mein-foto.webp" --out "assets/img/mein-foto-1400.jpg"
```

Breite und Höhe des neuen Bildes als `width`/`height` im `<img>` eintragen, damit die Seite beim Laden nicht springt.

### Woher die Web-Bilder stammen

Die Originale in `images/` bleiben unverändert. Die Seite nutzt verkleinerte Kopien in `assets/img/`:

| Datei(en) in `assets/img/` | Quelle in `images/` | Verwendung |
|---|---|---|
| `hero-1920.webp`, `hero-1000.jpg` | `background1.webp` | Bild im Hero-Bereich, zentrierte Überschrift in dunkler Schrift darüber |
| `logo-156.png`, `favicon-32.png`, `favicon-64.png`, `apple-touch-icon.png` | `logo Kopie.png` | Hauptlogo in Kopf- und Fußbereich, Browser-Symbol |
| `ginkgo-logo.png` | `logo Kopie.png` | große, dezente Logo-Fläche (Dein Weg, Kontakt, Über mich) |
| `ginkgo-icon.png` | `home-icon Kopie.png` | kleines Deko-Icon (Angebots-Hinweis, Rezension, Platzhalter) |
| `og-image.jpg` | `background1.webp` | Vorschaubild beim Teilen des Links |
| übrige Fotos | Studio-, Kurs- und Retreat-Fotos | Angebote, Studio, Events, Über mich |

## Sieht die Seite nach einer Änderung noch alt aus?

Der Browser merkt sich Stylesheets und Skripte. Einmal hart neu laden: **Cmd+Shift+R** (Mac) bzw. **Strg+Shift+R** (Windows).

## Lokale Vorschau

Doppelklick auf `index.html` genügt. Alternativ mit Server:

```bash
python3 -m http.server 5188
```

Dann `http://localhost:5188` öffnen.
